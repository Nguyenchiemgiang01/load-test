package Test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Box;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JList;
import java.awt.ScrollPane;
import javax.swing.JTree;
import javax.swing.JTextArea;

public class main {

	private JFrame frame;
	private final JLabel lblNewLabel = new JLabel("Protocol:");
	private JTextField txtip;
	private JTextField txtprotocol;
	private JTextField txtpath;
	private JTextField txtmethod;
	private JTextField txtnumthread;
	private JTextField txtrampup;
	private JTextArea textArea;
	private JLabel lblBodyData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main window = new main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	
		
		
	}

	/**
	 * Create the application.
	 */
	public main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(50, 50, 1200, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		
		
		
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(604, 21, 126, 56);
		frame.getContentPane().add(lblNewLabel);
		
		txtip = new JTextField();
		txtip.setBounds(218, 36, 190, 36);
		frame.getContentPane().add(txtip);
		txtip.setColumns(10);
		
		txtprotocol = new JTextField();
		txtprotocol.setColumns(10);
		txtprotocol.setBounds(754, 36, 209, 36);
		frame.getContentPane().add(txtprotocol);
		
		JLabel lblIp = new JLabel("IP(server name):");
		lblIp.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIp.setBounds(30, 21, 178, 56);
		frame.getContentPane().add(lblIp);
		
		txtpath = new JTextField();
		txtpath.setColumns(10);
		txtpath.setBounds(218, 108, 190, 36);
		frame.getContentPane().add(txtpath);
		
		JLabel lblPath = new JLabel("Path:");
		lblPath.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPath.setBounds(30, 108, 178, 56);
		frame.getContentPane().add(lblPath);
		
		JLabel lblMethod = new JLabel("Method:");
		lblMethod.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblMethod.setBounds(604, 108, 126, 56);
		frame.getContentPane().add(lblMethod);
		
		txtmethod = new JTextField();
		txtmethod.setColumns(10);
		txtmethod.setBounds(754, 110, 209, 36);
		frame.getContentPane().add(txtmethod);
		
		JLabel lblNumberthread = new JLabel("Number Thread");
		lblNumberthread.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNumberthread.setBounds(30, 183, 165, 56);
		frame.getContentPane().add(lblNumberthread);
		
		txtnumthread = new JTextField();
		txtnumthread.setColumns(10);
		txtnumthread.setBounds(218, 189, 190, 36);
		frame.getContentPane().add(txtnumthread);

		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(154, 269, 104, 56);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblRampup = new JLabel("Ramp-up period(s)");
		lblRampup.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblRampup.setBounds(540, 174, 200, 56);
		frame.getContentPane().add(lblRampup);
		
		txtrampup = new JTextField();
		txtrampup.setColumns(10);
		txtrampup.setBounds(750,180,209,36);
		frame.getContentPane().add(txtrampup);
		
		textArea = new JTextArea();
		textArea.setBounds(573, 289, 404, 179);
		frame.getContentPane().add(textArea);
		
		lblBodyData = new JLabel("Body data:");
		lblBodyData.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBodyData.setBounds(428, 338, 126, 56);
		frame.getContentPane().add(lblBodyData);
		
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
						String protocol= new String (txtprotocol.getText());
						String ip= new String(txtip.getText());
						String path= new String(txtpath.getText());
						String method= new String(txtmethod.getText());
						String numberthread= new String(txtnumthread.getText());
						Long ramup = Long.valueOf(txtrampup.getText());
						String post_parras= new String(textArea.getText());
						
						ThreadRequest threadRequest= new ThreadRequest(protocol, ip, method, path,Integer.valueOf(numberthread),ramup,post_parras);
						List<List<Long>> list = new ArrayList<List<Long>>();
						try {
							list = ThreadRequest.request();
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ExecutionException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
//						String[] data= new String[Integer.valueOf(numberthread)];
//						list.toArray(data);		
//						Object[] objects= new Object[Integer.valueOf(numberthread)];
						String col[] = {"name","time response","Time start","Status"};
						String[][] row = new String[Integer.parseInt(numberthread)][4];
						JTable table = new JTable(row,col);
						

						String sumary_col[] = {"Total","Min","Max","Average","Throughput","Latency"};
						String[][] sumary_row = new String[1] [6];
						JTable table_sumary = new JTable(sumary_row,sumary_col);
						for(int i=0;i<Integer.parseInt(numberthread);i++)
						{
							row[i][0] = "thread " + i;
							row[i][1] = String.valueOf(list.get(i).get(0));
							row[i][2]= 	String.valueOf(list.get(i).get(1));
							long status_code = list.get(i).get(2);
							if(status_code>199 && status_code<300) {
								row[i][3] = "Success";
								}
							else if(status_code>399 && status_code<500) {
								row[i][3] = "Client ERROR";
							}
							else if(status_code>499  && status_code<600) {
								row[i][3] = "Server ERROR";
							}
							else {
								row[i][3] = "Can't connect";
							}
							
						}
						
						long max_ts_t=Long.valueOf(row[0][2])+Long.valueOf(row[0][1]);
						long min_ts_t=Long.valueOf(row[0][2])+Long.valueOf(row[0][1]);
						
						long max_t=Long.valueOf(row[0][1]);
						long min_t=Long.valueOf(row[0][1]);
						
						long min_ts=Long.valueOf(row[0][2]);
						
						Double Sum=0.0;
						for(int i=0;i<Integer.parseInt(numberthread);i++) {
							max_ts_t=Math.max(max_ts_t,Long.valueOf(row[i][2])+Long.valueOf(row[i][1]) );
							min_ts_t=Math.min(min_ts_t,Long.valueOf(row[i][2])+Long.valueOf(row[i][1]) );
							
							max_t=Math.max(max_t,Long.valueOf(row[i][1]) );
							min_t=Math.min(min_t,Long.valueOf(row[i][1]) );
							
							min_ts=Math.max(min_ts,Long.valueOf(row[i][2]) );
							
							Sum+=Long.valueOf(row[i][1]);
						}
						
						
						Long Latency=min_ts_t-min_ts;
						double throughput=1000*Integer.parseInt(numberthread)*1.0/(max_ts_t-min_ts);	
//						System.out.print(throughput);
//						System.out.print(Latency);
						
						
						sumary_row[0][0]=numberthread;
						sumary_row[0][1]=String.valueOf(min_t);
						sumary_row[0][2]=String.valueOf(max_t);
						sumary_row[0][3]=String.valueOf(Sum/Integer.parseInt(numberthread));
						sumary_row[0][4]=String.valueOf(throughput);
						sumary_row[0][5]=String.valueOf(Latency);
					
						
						JScrollPane sp = new JScrollPane(table);
						sp.setBounds(50, 500, 900, 150);
						frame.getContentPane().add(sp);
						
						JScrollPane Summary_Report = new JScrollPane(table_sumary);
						Summary_Report.setBounds(50, 700, 900, 50);
						frame.getContentPane().add(Summary_Report);
			}
		});
	}
}